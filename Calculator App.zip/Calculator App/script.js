let display = document.getElementById('display');

function appendToDisplay(value) {
    if (display.innerText === '0' && value !== '.') {
        display.innerText = value;
    } else {
        display.innerText += value;
    }
}

function clearDisplay() {
    display.innerText = '0';
}

function calculate() {
    try {
        // Replace any instances of multiple operators with a single operator
        let expression = display.innerText.replace(/[\+\-\*\/%]{2,}/g, function(match) {
            return match.charAt(0);
        });
        display.innerText = eval(expression);
    } catch (e) {
        display.innerText = 'Error';
    }
}
