document.addEventListener('DOMContentLoaded', function() {
    loadTodos();
});

function addTodo() {
    const newTodoInput = document.getElementById('newTodo');
    const task = newTodoInput.value.trim();

    if (task) {
        fetch('http://localhost/todo-app/server/add_todo.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ task })
        })
        .then(response => response.json())
        .then(data => {
            newTodoInput.value = '';
            loadTodos();
        });
    }
}

function deleteTodo(id) {
    fetch('http://localhost/todo-app/server/delete_todo.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id })
    })
    .then(response => response.json())
    .then(data => {
        loadTodos();
    });
}

function loadTodos() {
    fetch('http://localhost/todo-app/server/get_todos.php')
    .then(response => response.json())
    .then(data => {
        const todoList = document.getElementById('todoList');
        todoList.innerHTML = '';

        data.todos.forEach(todo => {
            const li = document.createElement('li');
            li.innerHTML = `
                ${todo.task}
                <button class="delete" onclick="deleteTodo(${todo.id})">Delete</button>
            `;
            todoList.appendChild(li);
        });
    });
}
