<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? 0;

if ($id) {
    $filename = '../data/todos.json';
    $todos = json_decode(file_get_contents($filename), true);
    $todos = array_filter($todos, function($todo) use ($id) {
        return $todo['id'] != $id;
    });
    file_put_contents($filename, json_encode(array_values($todos)));
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid ID']);
}
?>
