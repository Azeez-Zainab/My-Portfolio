<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$task = $data['task'] ?? '';

if ($task) {
    $filename = '../data/todos.json';
    $todos = json_decode(file_get_contents($filename), true);
    $id = count($todos) > 0 ? max(array_column($todos, 'id')) + 1 : 1;
    $todos[] = ['id' => $id, 'task' => $task];
    file_put_contents($filename, json_encode($todos));
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Task is empty']);
}
?>
