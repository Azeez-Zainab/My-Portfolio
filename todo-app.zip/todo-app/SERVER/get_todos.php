<?php
header('Content-Type: application/json');

$filename = '../data/todos.json';
$todos = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
echo json_encode(['todos' => $todos]);
?>
